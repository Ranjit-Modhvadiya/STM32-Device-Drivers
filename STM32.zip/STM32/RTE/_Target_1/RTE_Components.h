
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Timer_1(delay)' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f3xx.h"

/* Keil.Standalone::Device:Startup:1.11.3 */
#define RTE_DEVICE_STARTUP_STM32F3XX    /* Device Startup for STM32F3 */


#endif /* RTE_COMPONENTS_H */
