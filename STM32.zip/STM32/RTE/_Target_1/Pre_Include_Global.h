
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Project' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* Keil.STM32CubeMX::Device:STM32Cube HAL:1.11.3 */
#define USE_HAL_DRIVER
          #define USE_FULL_LL_DRIVER


#endif /* PRE_INCLUDE_GLOBAL_H */
